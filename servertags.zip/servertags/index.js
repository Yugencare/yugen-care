const axios = require("axios");

module.exports = getPageData = async (url) => {
  try {
    const response = await axios.get(
      "https://cms.yugencare.com/api/v1/pages/meta-tags/" + url
    );
    const data = response.data.data;
    const string = {
      meta: data.meta,
      schema: data.schema,
      properties: JSON.stringify(data.properties),
    };
    return string;
  } catch (e) {
    console.log(e);
  }
};

// const data = getPageData();
// module.exports.DATA = data;
